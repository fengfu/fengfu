package io.fengfu.learning.instrument;

import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;

/**
 * Created by fengfu.qu on 2016/4/24.
 */
public class DynamicAgent {
    public static void agentmain(String agentArgs, Instrumentation _inst){
        System.out.println("Adding a SampleTransformer instance to the JVM.");
        _inst.addTransformer(new SampleTransformer(), true);
        try {
            _inst.retransformClasses(SampleApp.class);
        } catch (UnmodifiableClassException e) {
            e.printStackTrace();
        }
    }
}
