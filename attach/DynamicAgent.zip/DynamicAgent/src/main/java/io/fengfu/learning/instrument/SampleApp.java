package io.fengfu.learning.instrument;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by fengfu.qu on 2016/4/24.
 */
public class SampleApp {
    public static void main(String[] args) {
        System.out.println("Please input the command test, or bye to exit.");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            while(!"bye".equalsIgnoreCase(br.readLine())){
                new Test().test();
            }
            System.out.println("See you then.");
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}