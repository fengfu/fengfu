package io.fengfu.learning.instrument;

import com.sun.tools.attach.AgentInitializationException;
import com.sun.tools.attach.AgentLoadException;
import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;

import java.io.IOException;

/**
 * Created by fengfu.qu on 2016/4/25.
 */
public class AgentLoader {
    public static void main(String[] args) {
        try {
            VirtualMachine vm = VirtualMachine.attach(args[0]);
            vm.loadAgent("D:/Fengfu/Intellij_Idea/DynamicAgent/target/DynamicAgent-1.0-SNAPSHOT.jar");
        } catch (AttachNotSupportedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (AgentInitializationException e) {
            e.printStackTrace();
        } catch (AgentLoadException e) {
            e.printStackTrace();
        }
    }
}